package com.exemplo.gerenciamento.service;

import com.exemplo.gerenciamento.dto.ReservaDTO;
import com.exemplo.gerenciamento.exception.DataReservaInvalidException; 
import com.exemplo.gerenciamento.exception.SalaNotFoundException;
import com.exemplo.gerenciamento.exception.ReservaNotFoundException;
import com.exemplo.gerenciamento.model.Reserva;
import com.exemplo.gerenciamento.model.Sala;
import com.exemplo.gerenciamento.model.Usuario;
import com.exemplo.gerenciamento.repository.ReservaRepository;
import com.exemplo.gerenciamento.repository.SalaRepository;
import com.exemplo.gerenciamento.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class ReservaService {

    @Autowired
    private ReservaRepository reservaRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private SalaRepository salaRepository;

    // Método para criar uma reserva
    public Reserva criarReserva(List<Long> usuarioIds, List<Long> salaIds, LocalDateTime dataHoraInicio, LocalDateTime dataHoraFim) {
        // Validações de data e disponibilidade
        if (dataHoraInicio.isAfter(dataHoraFim)) {
            throw new DataReservaInvalidException("A data de início não pode ser maior que a data de fim.");
        }

        if (dataHoraInicio.isBefore(LocalDateTime.now())) {
            throw new DataReservaInvalidException("Não é possível reservar para uma data passada.");
        }

        if (dataHoraInicio.isAfter(LocalDateTime.now().plusDays(30))) {
            throw new DataReservaInvalidException("A reserva só pode ser feita com no máximo 30 dias de antecedência.");
        }

        if (salaIds == null || salaIds.isEmpty()) {
            throw new IllegalArgumentException("Os IDs das salas não podem ser nulos ou vazios.");
        }

        for (Long salaId : salaIds) {
            if (!isSalaDisponivel(salaId, dataHoraInicio, dataHoraFim)) {
                throw new RuntimeException("A sala com ID " + salaId + " já está reservada para o período especificado.");
            }
        }

        for (Long usuarioId : usuarioIds) {
            if (hasReservaAtiva(usuarioId, dataHoraInicio, dataHoraFim)) {
                throw new RuntimeException("O usuário com ID " + usuarioId + " já tem uma reserva ativa no mesmo horário.");
            }
        }

        Reserva reserva = new Reserva();
        reserva.setDataReserva(LocalDateTime.now());
        reserva.setDataHoraInicio(dataHoraInicio);
        reserva.setDataHoraFim(dataHoraFim);

        Set<Usuario> usuarios = new HashSet<>();
        for (Long usuarioId : usuarioIds) {
            Usuario usuario = usuarioRepository.findById(usuarioId)
                    .orElseThrow(() -> new RuntimeException("Usuário não encontrado com ID: " + usuarioId));
            usuarios.add(usuario);
        }
        reserva.setUsuarios(usuarios);

        Set<Sala> salas = new HashSet<>();
        for (Long salaId : salaIds) {
            Sala sala = salaRepository.findById(salaId)
                    .orElseThrow(() -> new SalaNotFoundException("Sala não encontrada com ID: " + salaId));
            if (!sala.isAtiva()) {
                throw new RuntimeException("Sala inativa não pode ser reservada.");
            }
            salas.add(sala);
        }
        reserva.setSalas(salas);

        return reservaRepository.save(reserva);
    }

    // Listar todas as reservas
    public List<Reserva> listarReservas() {
        return reservaRepository.findAll();
    }

    // Obter reserva por ID
    public Reserva obterReservaPorId(Long id) {
        return reservaRepository.findById(id)
                .orElseThrow(() -> new ReservaNotFoundException("Reserva não encontrada com ID: " + id));
    }

    // Atualizar uma reserva existente
    public ReservaDTO atualizarReserva(Long id, ReservaDTO reservaAtualizada) {
        Optional<Reserva> reservaOptional = reservaRepository.findById(id);
        if (reservaOptional.isPresent()) {
            Reserva reserva = reservaOptional.get();

            if (reservaAtualizada.getDataHoraInicio().isAfter(reservaAtualizada.getDataHoraFim())) {
                throw new DataReservaInvalidException("A data de início não pode ser maior que a data de fim.");
            }

            if (reservaAtualizada.getDataHoraInicio().isBefore(LocalDateTime.now())) {
                throw new DataReservaInvalidException("Não é possível atualizar a reserva para uma data passada.");
            }

            reserva.setDataHoraInicio(reservaAtualizada.getDataHoraInicio());
            reserva.setDataHoraFim(reservaAtualizada.getDataHoraFim());

            Set<Usuario> usuarios = new HashSet<>();
            for (Usuario usuario : reservaAtualizada.getUsuarios()) {
                Usuario usuarioExistente = usuarioRepository.findById(usuario.getId())
                        .orElseThrow(() -> new RuntimeException("Usuário não encontrado com ID: " + usuario.getId()));
                usuarios.add(usuarioExistente);
            }
            reserva.setUsuarios(usuarios);

            Set<Sala> salas = new HashSet<>();
            for (Sala sala : reservaAtualizada.getSalas()) {
                Sala salaExistente = salaRepository.findById(sala.getId())
                        .orElseThrow(() -> new SalaNotFoundException("Sala não encontrada com ID: " + sala.getId()));
                if (!salaExistente.isAtiva()) {
                    throw new RuntimeException("Sala inativa não pode ser reservada.");
                }
                salas.add(salaExistente);
            }
            reserva.setSalas(salas);

            reservaRepository.save(reserva); 
            return mapToDTO(reserva);
        } else {
            throw new ReservaNotFoundException("Reserva não encontrada com ID: " + id);
        }
    }

    // Mapear Reserva para ReservaDTO
    private ReservaDTO mapToDTO(Reserva reserva) {
        ReservaDTO dto = new ReservaDTO();
        dto.setId(reserva.getId());
        dto.setUsuarios(new ArrayList<>(reserva.getUsuarios()));
        dto.setSalas(new ArrayList<>(reserva.getSalas()));
        dto.setDataHoraInicio(reserva.getDataHoraInicio());
        dto.setDataHoraFim(reserva.getDataHoraFim());
        dto.setDataReserva(reserva.getDataReserva());
        return dto;
    }

    // Deletar uma reserva
    public void deletarReserva(Long id) {
        if (reservaRepository.existsById(id)) {
            reservaRepository.deleteById(id);
        } else {
            throw new ReservaNotFoundException("Reserva não encontrada com ID: " + id);
        }
    }

    // Verificar se a sala está disponível
    public boolean isSalaDisponivel(Long salaId, LocalDateTime dataHoraInicio, LocalDateTime dataHoraFim) {
        List<Reserva> reservas = reservaRepository.findBySalas_Id(salaId);
        for (Reserva reserva : reservas) {
            if (reserva.getDataHoraInicio().isBefore(dataHoraFim) && reserva.getDataHoraFim().isAfter(dataHoraInicio)) {
                return false;
            }
        }
        return true;
    }

    // Verificar se o usuário já tem reserva ativa no período
    public boolean hasReservaAtiva(Long usuarioId, LocalDateTime dataHoraInicio, LocalDateTime dataHoraFim) {
        List<Reserva> reservasUsuario = reservaRepository.findByUsuarios_Id(usuarioId);
        for (Reserva reserva : reservasUsuario) {
            if (reserva.getDataHoraInicio().isBefore(dataHoraFim) && reserva.getDataHoraFim().isAfter(dataHoraInicio)) {
                return true;
            }
        }
        return false;
    }

    // Métodos de busca e filtragem:

    // Buscar reservas por usuário
    public List<Reserva> listarReservasPorUsuario(Long userId) {
        return reservaRepository.findByUsuarios_Id(userId);
    }

    // Buscar reservas por sala
    public List<Reserva> listarReservasPorSala(Long salaId) {
        return reservaRepository.findBySalas_Id(salaId);
    }

    // Buscar reservas por data específica
    public List<Reserva> buscarReservasPorData(LocalDateTime data) {
        return reservaRepository.findByDataHoraInicioBetween(data.toLocalDate().atStartOfDay(), data.toLocalDate().atTime(23, 59, 59));
    }

    // Buscar reservas entre datas
    public List<Reserva> buscarReservasEntreDatas(LocalDateTime dataInicio, LocalDateTime dataFim) {
        return reservaRepository.findByDataHoraInicioBetween(dataInicio, dataFim);
    }

    // Buscar reservas por usuário e intervalo de datas
    public List<Reserva> buscarReservasPorUsuarioEDatas(Long usuarioId, LocalDateTime dataInicio, LocalDateTime dataFim) {
        return reservaRepository.findByUsuarios_IdAndDataHoraInicioBetween(usuarioId, dataInicio, dataFim);
    }

    // Buscar reservas por sala e intervalo de datas
    public List<Reserva> buscarReservasPorSalaEDatas(Long salaId, LocalDateTime dataInicio, LocalDateTime dataFim) {
        return reservaRepository.findBySalas_IdAndDataHoraInicioBetween(salaId, dataInicio, dataFim);
    }
}
package com.exemplo.gerenciamento.dto;

import com.exemplo.gerenciamento.model.Sala;
import com.exemplo.gerenciamento.model.Usuario;

import java.time.LocalDateTime;
import java.util.List;

public class ReservaDTO {
    private Long id;	
    private List<Usuario> usuarios;  // Lista de usuários associados à reserva
    private List<Sala> salas;        // Lista de salas associadas à reserva
    private LocalDateTime dataHoraInicio; // Data e hora de início da reserva
    private LocalDateTime dataHoraFim;    // Data e hora de fim da reserva
    private LocalDateTime dataReserva;     // Data e hora em que a reserva foi feita

    // Construtor padrão
    public ReservaDTO() {}

    // Construtor com parâmetros
    public ReservaDTO(Long id, List<Usuario> usuarios, List<Sala> salas,
                      LocalDateTime dataHoraInicio, LocalDateTime dataHoraFim, 
                      LocalDateTime dataReserva) {
        this.id = id;
        this.usuarios = usuarios;
        this.salas = salas;
        this.dataHoraInicio = dataHoraInicio;
        this.dataHoraFim = dataHoraFim;
        this.dataReserva = dataReserva;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    public List<Sala> getSalas() {
        return salas;
    }

    public void setSalas(List<Sala> salas) {
        this.salas = salas;
    }

    public LocalDateTime getDataHoraInicio() {
        return dataHoraInicio;
    }

    public void setDataHoraInicio(LocalDateTime dataHoraInicio) {
        this.dataHoraInicio = dataHoraInicio;
    }

    public LocalDateTime getDataHoraFim() {
        return dataHoraFim;
    }

    public void setDataHoraFim(LocalDateTime dataHoraFim) {
        this.dataHoraFim = dataHoraFim;
    }

    public LocalDateTime getDataReserva() {
        return dataReserva;
    }

    public void setDataReserva(LocalDateTime dataReserva) {
        this.dataReserva = dataReserva;
    }
}
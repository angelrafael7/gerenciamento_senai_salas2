package com.exemplo.gerenciamento.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Entity
@Table(name = "reservas")
public class Reserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToMany // Permitir múltiplas salas
    @JoinTable(
            name = "reserva_sala",
            joinColumns = @JoinColumn(name = "reserva_id"),
            inverseJoinColumns = @JoinColumn(name = "sala_id")
    )
    private Set<Sala> salas = new HashSet<>();

    @ManyToMany
    @JoinTable(
            name = "reserva_usuario",
            joinColumns = @JoinColumn(name = "reserva_id"),
            inverseJoinColumns = @JoinColumn(name = "usuario_id")
    )
    private Set<Usuario> usuarios = new HashSet<>();

    @Column(name = "data_reserva", nullable = false)
    private LocalDateTime dataReserva;

    @Column(nullable = false)
    private LocalDateTime dataHoraInicio;

    @Column(nullable = false)
    private LocalDateTime dataHoraFim;

    // Construtor padrão
    public Reserva() {}

    // Construtor com parâmetros
    public Reserva(Set<Sala> salas, Set<Usuario> usuarios, LocalDateTime dataReserva, LocalDateTime dataHoraInicio, LocalDateTime dataHoraFim) {
        this.salas = salas;
        this.usuarios = usuarios;
        this.dataReserva = dataReserva;
        this.dataHoraInicio = dataHoraInicio;
        this.dataHoraFim = dataHoraFim;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Set<Sala> getSalas() {
        return salas;
    }

    public void setSalas(Set<Sala> salas) {
        this.salas = salas;
    }

    public Set<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(Set<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    public LocalDateTime getDataReserva() {
        return dataReserva;
    }

    public void setDataReserva(LocalDateTime dataReserva) {
        this.dataReserva = dataReserva;
    }

    public LocalDateTime getDataHoraInicio() {
        return dataHoraInicio;
    }

    public void setDataHoraInicio(LocalDateTime dataHoraInicio) {
        this.dataHoraInicio = dataHoraInicio;
    }

    public LocalDateTime getDataHoraFim() {
        return dataHoraFim;
    }

    public void setDataHoraFim(LocalDateTime dataHoraFim) {
        this.dataHoraFim = dataHoraFim;
    }

    // Método para obter os IDs das salas associadas à reserva
    public List<Long> getSalaIds() {
        return salas.stream()
                    .map(Sala::getId)  // Supondo que você tenha um método getId() na entidade Sala
                    .collect(Collectors.toList());
    }
}
package com.exemplo.gerenciamento.service;

import com.exemplo.gerenciamento.model.Sala;
import com.exemplo.gerenciamento.repository.SalaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SalaService {

    @Autowired
    private SalaRepository salaRepository;

    // Criar uma nova sala
    public Sala criarSala(Sala sala) {
        return salaRepository.save(sala); // O ID é gerado automaticamente aqui
    }

    // Criar várias salas
    public List<Sala> criarSalas(List<Sala> salas) {
        return salaRepository.saveAll(salas);
    }

    // Listar todas as salas
    public List<Sala> listarSalas() {
        return salaRepository.findAll();
    }

    // Listar todas as salas ativas
    public List<Sala> listarSalasAtivas() {
        return salaRepository.findByStatus(true);
    }

    // Buscar uma sala por ID
    public Optional<Sala> buscarSalaPorId(Long id) {
        return salaRepository.findById(id);
    }

    // Atualizar uma sala existente
    public Sala atualizarSala(Long id, Sala salaAtualizada) {
        Optional<Sala> salaOptional = salaRepository.findById(id);
        if (salaOptional.isPresent()) {
            Sala sala = salaOptional.get();
            sala.setNome(salaAtualizada.getNome());
            sala.setDepartamento(salaAtualizada.getDepartamento());
            sala.setStatus(salaAtualizada.isStatus());
            sala.setCapacidade(salaAtualizada.getCapacidade());
            return salaRepository.save(sala);
        } else {
            throw new RuntimeException("Sala não encontrada com ID: " + id);
        }
    }

    // Deletar uma sala
    public void deletarSala(Long id) {
        if (salaRepository.existsById(id)) {
            salaRepository.deleteById(id);
            reorganizarIds(); // Chama a reorganização após deletar
        } else {
            throw new RuntimeException("Sala não encontrada com ID: " + id);
        }
    }

    // Reorganizar IDs das salas
    private void reorganizarIds() {
        List<Sala> salas = salaRepository.findAll();

        for (int i = 0; i < salas.size(); i++) {
            Sala sala = salas.get(i);
            sala.setId((long) (i + 1)); // Ajusta o ID para começar de 1
        }

        salaRepository.saveAll(salas); // Salva as salas com os IDs atualizados
    }

    // Buscar salas ativas por nome
    public List<Sala> buscarSalasAtivasPorNome(String nome) {
        return salaRepository.findByNomeAndStatus(nome, true);
    }

    // Buscar salas ativas por departamento
    public List<Sala> buscarSalasAtivasPorDepartamento(String departamento) {
        return salaRepository.findByDepartamentoAndStatus(departamento, true);
    }

    // Buscar salas ativas por termo
    public List<Sala> buscarSalasAtivasPorTermo(String termo) {
        return salaRepository.findByNomeContainingIgnoreCaseAndStatus(termo, true);
    }
}
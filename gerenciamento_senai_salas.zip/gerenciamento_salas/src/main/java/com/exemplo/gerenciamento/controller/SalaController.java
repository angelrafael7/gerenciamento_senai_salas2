package com.exemplo.gerenciamento.controller;

import com.exemplo.gerenciamento.model.Sala;
import com.exemplo.gerenciamento.service.SalaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/salas")
public class SalaController {

    @Autowired
    private SalaService salaService;

    // Criar uma nova sala
    @PostMapping
    public ResponseEntity<Sala> criarSala(@RequestBody Sala sala) {
        // Verifica se o ID já existe
        if (salaService.buscarSalaPorId(sala.getId()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build(); // ID já existe
        }
        // Cria a nova sala
        Sala novaSala = salaService.criarSala(sala);
        return ResponseEntity.status(HttpStatus.CREATED).body(novaSala);
    }

    // Criar várias salas
    @PostMapping("/multiplas")
    public ResponseEntity<List<Sala>> criarSalas(@RequestBody List<Sala> salas) {
        // Verifica se algum ID já existe
        for (Sala sala : salas) {
            if (salaService.buscarSalaPorId(sala.getId()).isPresent()) {
                return ResponseEntity.status(HttpStatus.CONFLICT).build(); // ID já existe
            }
        }
        // Cria as salas
        List<Sala> salasSalvas = salaService.criarSalas(salas);
        return ResponseEntity.status(HttpStatus.CREATED).body(salasSalvas);
    }

    // Listar todas as salas
    @GetMapping
    public ResponseEntity<List<Sala>> listarSalas() {
        List<Sala> salas = salaService.listarSalas();
        return ResponseEntity.ok(salas);
    }

    // Buscar sala por ID
    @GetMapping("/{id}")
    public ResponseEntity<Sala> buscarSalaPorId(@PathVariable Long id) {
        Optional<Sala> sala = salaService.buscarSalaPorId(id);
        return sala.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Atualizar sala
    @PutMapping("/{id}")
    public ResponseEntity<Sala> atualizarSala(@PathVariable Long id, @RequestBody Sala salaAtualizada) {
        try {
            Sala sala = salaService.atualizarSala(id, salaAtualizada);
            return ResponseEntity.ok(sala);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Excluir sala
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarSala(@PathVariable Long id) {
        salaService.deletarSala(id);
        return ResponseEntity.noContent().build();
    }
}
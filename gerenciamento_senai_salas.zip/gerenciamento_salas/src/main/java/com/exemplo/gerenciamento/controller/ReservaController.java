package com.exemplo.gerenciamento.controller;

import com.exemplo.gerenciamento.dto.ReservaDTO;
import com.exemplo.gerenciamento.dto.ReservaRequest;
import com.exemplo.gerenciamento.model.Reserva;
import com.exemplo.gerenciamento.service.ReservaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/reservas")
public class ReservaController {

    @Autowired
    private ReservaService reservaService;

    // Método para criar uma nova reserva com múltiplos usuários e salas
    @PostMapping
    public ResponseEntity<Reserva> criarReserva(@RequestBody ReservaRequest request) {
        // Chama o serviço para criar a reserva passando as IDs dos usuários e das salas
        Reserva novaReserva = reservaService.criarReserva(request.getUsuarioIds(), request.getSalaIds(), request.getDataHoraInicio(), request.getDataHoraFim());
        return ResponseEntity.status(HttpStatus.CREATED).body(novaReserva);
    }

    // Método para listar todas as reservas
    @GetMapping
    public ResponseEntity<List<Reserva>> listarReservas() {
        List<Reserva> reservas = reservaService.listarReservas();
        return ResponseEntity.ok(reservas);
    }

    // Método para obter uma reserva por ID
    @GetMapping("/{id}")
    public ResponseEntity<Reserva> obterReservaPorId(@PathVariable Long id) {
        Reserva reserva = reservaService.obterReservaPorId(id);
        return ResponseEntity.ok(reserva);
    }

    // Método para atualizar uma reserva existente
    @PutMapping("/{id}")
    public ResponseEntity<ReservaDTO> atualizarReserva(@PathVariable Long id, @RequestBody ReservaDTO reservaAtualizada) {
        ReservaDTO reservaAtualizadaResponse = reservaService.atualizarReserva(id, reservaAtualizada);
        return ResponseEntity.ok(reservaAtualizadaResponse);
    }

    // Método para deletar uma reserva
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarReserva(@PathVariable Long id) {
        try {
            reservaService.deletarReserva(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    // Endpoint para listar todas as reservas feitas por um usuário
    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<List<Reserva>> listarReservasPorUsuario(@PathVariable Long usuarioId) {
        List<Reserva> reservas = reservaService.listarReservasPorUsuario(usuarioId);
        if (reservas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(reservas);
    }

    // Endpoint para listar todas as reservas de uma sala específica
    @GetMapping("/salas/{salaId}")
    public ResponseEntity<List<Reserva>> listarReservasPorSala(@PathVariable Long salaId) {
        List<Reserva> reservas = reservaService.listarReservasPorSala(salaId);
        if (reservas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(reservas);
    }

    // Endpoint para buscar reservas por data específica
    @GetMapping("/data/{data}")
    public ResponseEntity<List<Reserva>> buscarReservasPorData(@PathVariable String data) {
        LocalDateTime dataHora = LocalDateTime.parse(data); // Certifique-se de que o formato está correto
        List<Reserva> reservas = reservaService.buscarReservasPorData(dataHora);
        return reservas.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(reservas);
    }

    // Endpoint para buscar reservas entre datas
    @GetMapping("/datas")
    public ResponseEntity<List<Reserva>> buscarReservasEntreDatas(@RequestParam String dataInicio, @RequestParam String dataFim) {
        LocalDateTime inicio = LocalDateTime.parse(dataInicio);
        LocalDateTime fim = LocalDateTime.parse(dataFim);
        List<Reserva> reservas = reservaService.buscarReservasEntreDatas(inicio, fim);
        return reservas.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(reservas);
    }

    // Endpoint para buscar reservas por usuário e intervalo de datas
    @GetMapping("/usuario/{usuarioId}/datas")
    public ResponseEntity<List<Reserva>> buscarReservasPorUsuarioEDatas(@PathVariable Long usuarioId, 
                                                                         @RequestParam String dataInicio, 
                                                                         @RequestParam String dataFim) {
        LocalDateTime inicio = LocalDateTime.parse(dataInicio);
        LocalDateTime fim = LocalDateTime.parse(dataFim);
        List<Reserva> reservas = reservaService.buscarReservasPorUsuarioEDatas(usuarioId, inicio, fim);
        return reservas.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(reservas);
    }

    // Endpoint para buscar reservas por sala e intervalo de datas
    @GetMapping("/salas/{salaId}/datas")
    public ResponseEntity<List<Reserva>> buscarReservasPorSalaEDatas(@PathVariable Long salaId, 
                                                                     @RequestParam String dataInicio, 
                                                                     @RequestParam String dataFim) {
        LocalDateTime inicio = LocalDateTime.parse(dataInicio);
        LocalDateTime fim = LocalDateTime.parse(dataFim);
        List<Reserva> reservas = reservaService.buscarReservasPorSalaEDatas(salaId, inicio, fim);
        return reservas.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(reservas);
    }
}
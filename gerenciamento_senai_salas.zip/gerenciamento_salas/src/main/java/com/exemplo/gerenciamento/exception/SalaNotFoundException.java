package com.exemplo.gerenciamento.exception;

public class SalaNotFoundException extends RuntimeException {
    public SalaNotFoundException(String message) {
        super(message);
    }
}
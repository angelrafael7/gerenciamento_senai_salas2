package com.exemplo.gerenciamento.service;

import com.exemplo.gerenciamento.exception.ResourceNotFoundException; // Importar a exceção
import com.exemplo.gerenciamento.model.Reserva; // Importar o modelo Reserva
import com.exemplo.gerenciamento.model.Usuario;
import com.exemplo.gerenciamento.repository.ReservaRepository; // Importar o repositório de reservas
import com.exemplo.gerenciamento.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private ReservaRepository reservaRepository; // Injeção do repositório de reservas

    public Usuario criarUsuario(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    public List<Usuario> listarUsuarios() {
        return usuarioRepository.findAll();
    }

    public Usuario atualizarUsuario(Long id, Usuario usuario) {
        usuario.setId(id);
        return usuarioRepository.save(usuario);
    }

    public void deletarUsuario(Long usuarioId) {
        // Encontrar o usuário pelo ID
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new ResourceNotFoundException("Usuário não encontrado"));

        // Marcar o usuário como excluído
        usuario.setExcluido(true);
        usuarioRepository.save(usuario); // Salva a alteração do usuário
    }

    public void restaurarUsuario(Long usuarioId) {
        // Encontrar o usuário pelo ID
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new ResourceNotFoundException("Usuário não encontrado"));

        // Marcar o usuário como não excluído
        usuario.setExcluido(false);
        usuarioRepository.save(usuario); // Salva a alteração do usuário
    }

    public void adicionarUsuariosNaReserva(Long reservaId, List<Long> usuarioIds) {
        // Encontrar a reserva pelo ID
        Reserva reserva = reservaRepository.findById(reservaId)
                .orElseThrow(() -> new ResourceNotFoundException("Reserva não encontrada"));

        // Encontrar os usuários pelos IDs
        List<Usuario> usuarios = usuarioRepository.findAllById(usuarioIds);

        // Adicionar os usuários à reserva
        reserva.getUsuarios().addAll(usuarios);

        // Salvar a reserva atualizada
        reservaRepository.save(reserva);
    }

    public void removerUsuariosDaReserva(Long reservaId, List<Long> usuarioIds) {
        // Encontrar a reserva pelo ID
        Reserva reserva = reservaRepository.findById(reservaId)
                .orElseThrow(() -> new ResourceNotFoundException("Reserva não encontrada"));

        // Remover os usuários da reserva
        reserva.getUsuarios().removeIf(usuario -> usuarioIds.contains(usuario.getId()));

        // Salvar a reserva atualizada
        reservaRepository.save(reserva);
    }
}
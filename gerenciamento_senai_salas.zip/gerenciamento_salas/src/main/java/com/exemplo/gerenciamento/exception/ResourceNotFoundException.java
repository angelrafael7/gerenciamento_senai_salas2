package com.exemplo.gerenciamento.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

// Anotação para definir o status HTTP 404 (Não Encontrado) para essa exceção
@ResponseStatus(HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException {
    
    // Construtor que aceita uma mensagem personalizada
    public ResourceNotFoundException(String message) {
        super(message);
    }

    // Construtor que aceita o nome do recurso e seu ID
    public ResourceNotFoundException(String resourceName, Long resourceId) {
        super(String.format("%s com ID %d não encontrado", resourceName, resourceId));
    }
}
package com.exemplo.gerenciamento.dto; // Certifique-se de que o pacote está correto

import java.time.LocalDateTime;
import java.util.List;

public class ReservaRequest {
    private List<Long> usuarioIds; // Lista de IDs de usuários
    private List<Long> salaIds; // Lista de IDs de salas
    private LocalDateTime dataHoraInicio; // Data e hora de início
    private LocalDateTime dataHoraFim; // Data e hora de fim

    // Getters e Setters
    public List<Long> getUsuarioIds() {
        return usuarioIds;
    }

    public void setUsuarioIds(List<Long> usuarioIds) {
        this.usuarioIds = usuarioIds;
    }

    public List<Long> getSalaIds() {
        return salaIds;
    }

    public void setSalaIds(List<Long> salaIds) {
        this.salaIds = salaIds;
    }

    public LocalDateTime getDataHoraInicio() {
        return dataHoraInicio;
    }

    public void setDataHoraInicio(LocalDateTime dataHoraInicio) {
        this.dataHoraInicio = dataHoraInicio;
    }

    public LocalDateTime getDataHoraFim() {
        return dataHoraFim;
    }

    public void setDataHoraFim(LocalDateTime dataHoraFim) {
        this.dataHoraFim = dataHoraFim;
    }
}
package com.exemplo.gerenciamento.repository;

import com.exemplo.gerenciamento.model.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ReservaRepository extends JpaRepository<Reserva, Long> {

    // Método para buscar reservas por ID do usuário
    List<Reserva> findByUsuarios_Id(Long usuarioId);
    
    // Método para buscar reservas por ID da sala
    List<Reserva> findBySalas_Id(Long salaId);
    
    // Método para buscar reservas dentro de um intervalo de datas
    List<Reserva> findByDataHoraInicioBetween(LocalDateTime inicio, LocalDateTime fim);
    
    // Método adicional: buscar reservas por ID do usuário e dentro de um intervalo de datas
    List<Reserva> findByUsuarios_IdAndDataHoraInicioBetween(Long usuarioId, LocalDateTime inicio, LocalDateTime fim);
    
    // Método adicional: buscar reservas por ID da sala e dentro de um intervalo de datas
    List<Reserva> findBySalas_IdAndDataHoraInicioBetween(Long salaId, LocalDateTime inicio, LocalDateTime fim);
}
package com.exemplo.gerenciamento.exception;

public class DataReservaInvalidException extends RuntimeException {
    public DataReservaInvalidException(String message) {
        super(message);
    }
}
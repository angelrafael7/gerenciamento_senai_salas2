package com.exemplo.gerenciamento.repository;

import com.exemplo.gerenciamento.model.Sala;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SalaRepository extends JpaRepository<Sala, Long> {
	
    
    // Método para buscar todas as salas pelo status
    List<Sala> findByStatus(boolean status);
    
    // Método para buscar salas ativas por nome
    List<Sala> findByNomeAndStatus(String nome, boolean status);
    
    // Método para buscar salas ativas por departamento
    List<Sala> findByDepartamentoAndStatus(String departamento, boolean status);
    
    // Método para buscar salas ativas por nome ou departamento usando uma consulta personalizada
    @Query("SELECT s FROM Sala s WHERE s.status = true AND (s.nome LIKE %:searchTerm% OR s.departamento LIKE %:searchTerm%)")
    List<Sala> searchSalasAtivas(@Param("searchTerm") String searchTerm);
    
    // Método para buscar salas que contêm um termo específico no nome
    List<Sala> findByNomeContainingIgnoreCase(String nome);
    
    // Método para buscar salas que contêm um termo específico no nome e estão ativas
    List<Sala> findByNomeContainingIgnoreCaseAndStatus(String nome, boolean status); // Método atualizado para incluir status
}
package com.exemplo.gerenciamento.model;

import jakarta.persistence.*;

@Entity
@Table(name = "salas")
public class Sala {

    @Id
    private Long id; // Removido o @GeneratedValue para permitir a definição manual do ID

    @Column(nullable = false, unique = true) // Campo 'nome' não pode ser nulo e deve ser único
    private String nome;

    private String departamento; // Adiciona a informação do departamento

    @Column(nullable = false) // Campo 'status' não pode ser nulo
    private boolean status;  // Status ativo ou inativo

    @Column(nullable = false) // Campo 'capacidade' não pode ser nulo
    private Integer capacidade; // Adiciona o campo capacidade

    // Construtor padrão
    public Sala() {}

    // Construtor com parâmetros
    public Sala(Long id, String nome, String departamento, boolean status, Integer capacidade) {
        this.id = id; // Inicializa o ID
        this.nome = nome;
        this.departamento = departamento;
        this.status = status;
        this.capacidade = capacidade; // Inicializa o campo capacidade
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Integer getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(Integer capacidade) {
        this.capacidade = capacidade;
    }

    // Método para verificar se a sala está ativa
    public boolean isAtiva() {
        return this.status;
    }
}
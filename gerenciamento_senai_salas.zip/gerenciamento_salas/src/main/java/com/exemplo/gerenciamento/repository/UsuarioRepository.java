package com.exemplo.gerenciamento.repository;

import com.exemplo.gerenciamento.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
}
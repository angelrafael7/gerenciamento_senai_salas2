package com.exemplo.gerenciamento;

public @interface SpringBootTest {

}

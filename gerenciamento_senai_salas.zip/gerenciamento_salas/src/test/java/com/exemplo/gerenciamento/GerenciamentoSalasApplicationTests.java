package com.exemplo.gerenciamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootTest
class GerenciamentoSalasApplicationTests {

	@Test
	void contextLoads() {
	}

}
